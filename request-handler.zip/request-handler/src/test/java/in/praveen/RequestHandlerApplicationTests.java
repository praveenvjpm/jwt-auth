package in.praveen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RequestHandlerApplicationTests {

	@Test
	void contextLoads() {
	}

}
