package in.praveen.service;

import in.praveen.dto.AuthenticationResponse;
import in.praveen.dto.RegisterRequest;
import in.praveen.exception.InvalidPasswordException;
import in.praveen.model.Role;
import in.praveen.model.User;
import in.praveen.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserOperationsService {
    @Autowired
    private UserRepository userRepository;

    private final PasswordEncoder passwordEncoder;

    public void changePassword(RegisterRequest registerRequest) throws InvalidPasswordException {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        System.out.println(authentication.getName());
        User user = userRepository.findByEmail(registerRequest.getEmail()).orElseThrow();
        if(registerRequest.getPassword().equals(user.getPassword()) && registerRequest.getEmail().equals(authentication.getName())){
            user.setPassword(registerRequest.getNewPassword());
            return;
        }
        else{
            throw new InvalidPasswordException("Passwords Not matched");
        }
    }

    public ResponseEntity addUser(RegisterRequest registerRequest){
        User user = User.builder()
                .firstName(registerRequest.getFirstName())
                .lastName(registerRequest.getLastName())
                .email(registerRequest.getEmail())
                .password(passwordEncoder.encode("Standard@123"))
                .role(Role.USER)
                .CreatedBy("System")
                .createdDate(new Date(System.currentTimeMillis()))
                .updatedDate(new Date(System.currentTimeMillis()))
                .build();
        try {
            userRepository.save(user);
        }catch (Exception ex){
            ex.printStackTrace();
            return new ResponseEntity<>("User email already registered", HttpStatus.CONFLICT);
        }
        return new ResponseEntity<>("Resource created successfully.", HttpStatus.CREATED);

    }

    public ResponseEntity<List<in.praveen.dto.User>> userList(){
        List<User> users = userRepository.findByRoleIn(List.of("USER"));
        List<in.praveen.dto.User> userList= users.stream().map(user ->
            new in.praveen.dto.User(user.getId(),user.getFirstName(),user.getLastName(),user.getEmail())).collect(Collectors.toList());
        return new ResponseEntity<>(userList,HttpStatus.OK);
    }
}
