package in.praveen.service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;
import java.util.function.Function;

@Service
public class JwtService {
    private static final String SECRET_KEY ="616664a713fa175da0d9cf6d7297233bfff921f4a1a4698d19a8945dbf20c6c0";
    public String extractUserName(String token) {
        return extractClaim(token,Claims::getSubject);
    }

    public <T> T extractClaim(String token, Function<Claims,T> claimsResolver){
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    public String generateToken( UserDetails userDetails){
        return Jwts
                .builder()
                .subject(userDetails.getUsername())
                //.claims(extraClaims)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + (90 * 60 * 1000)))
                .signWith(getSecretKey())
                .compact();
    }

    public String generateToken(Map<String,Object> extraClaims, UserDetails userDetails){
        return Jwts
                .builder()
                .subject(userDetails.getUsername())
                .claims(extraClaims)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + (90 * 60 * 1000) ))
                .signWith(getSecretKey())
                .compact();
    }

    public boolean isTokenValid(String token,UserDetails userDetails){
        final String username = extractUserName(token);
        return (username.equals(userDetails.getUsername()) && ! isTokenExpired(token));
    }

    private boolean isTokenExpired(String token) {
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        Date utcDate = calendar.getTime();
        System.out.println("token time"+extractExpiration(token));
        System.out.println("local time"+utcDate);
        return extractExpiration(token).before(utcDate);
    }

    private Date extractExpiration(String token) {
        return extractClaim(token,Claims::getExpiration);
    }

    private SecretKey getSecretKey() {
        return Keys.hmacShaKeyFor(SECRET_KEY.getBytes(StandardCharsets.UTF_8));
    }

    private Claims extractAllClaims(String token){
        Jws<Claims> jws = Jwts.parser().verifyWith(getSecretKey()).build().parseSignedClaims(token);
        return jws.getPayload();
    }
}
