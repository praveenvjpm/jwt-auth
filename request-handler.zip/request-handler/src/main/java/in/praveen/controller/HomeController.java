package in.praveen.controller;

import in.praveen.dto.AuthenticationResponse;
import in.praveen.dto.RegisterRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class HomeController {
    @GetMapping("/welcome")
    public String welcome(){
        return "welcome endpoint";
    }

    @GetMapping("/user/userProfile")
    @PreAuthorize("hasRole('USER')")
    public String userRole(){
        return "user role authorized";
    }

    @GetMapping("/user/adminProfile")
    @PreAuthorize("hasRole('ADMIN')")
    public String adminRole(){
        return "admin role authorized";
    }

/*    @PostMapping("/register/manager")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<AuthenticationResponse> register(@RequestBody RegisterRequest registerRequest){
        return ResponseEntity.ok(authenticationService.register(registerRequest));
    }*/


}
