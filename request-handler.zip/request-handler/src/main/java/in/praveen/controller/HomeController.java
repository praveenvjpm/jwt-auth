package in.praveen.controller;

import in.praveen.dto.RegisterRequest;
import in.praveen.dto.User;
import in.praveen.exception.InvalidPasswordException;
import in.praveen.service.AuthenticationService;
import in.praveen.service.UserOperationsService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/user")
public class HomeController {
    @Autowired
    private UserOperationsService userOperationsService;

    @Autowired
    private AuthenticationService authenticationService;

    @GetMapping("/welcome")
    public String welcome(){
        return "welcome endpoint";
    }

    @GetMapping("/user/userProfile")
    @PreAuthorize("hasRole('MANAGER')")
    public String userRole(){
        return "user role authorized";
    }

    @GetMapping("/user/adminProfile")
    @PreAuthorize("hasRole('ADMIN')")
    public String adminRole(){
        return "admin role authorized";
    }

    //@PreAuthorize("hasRole('MANAGER')")
    @PreAuthorize("hasAuthority('MANAGER')")
    @PostMapping("/changePassword")
    public ResponseEntity changePassword(@RequestBody RegisterRequest registerRequest) throws InvalidPasswordException {
        System.out.println("Password change request received.........");
        userOperationsService.changePassword(registerRequest);
        return ResponseEntity.ok("Password updated successfully..........");
    }

    @PreAuthorize("hasAuthority('MANAGER')")
    @PostMapping("/addUser")
    public ResponseEntity<HttpStatus> register(@RequestBody RegisterRequest registerRequest){
        return userOperationsService.addUser(registerRequest);
    }

    @PreAuthorize("hasAuthority('MANAGER')")
    @PostMapping("/listUser")
    public ResponseEntity<List<User>> userList(){
        return userOperationsService.userList();
    }

    @PreAuthorize("hasAuthority('MANAGER')")
    @PostMapping("/logout")
    public void logout(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse){
       // return userOperationsService.userList();
        authenticationService.logout(httpServletRequest,httpServletResponse);
    }





/*    @PostMapping("/register/manager")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<AuthenticationResponse> register(@RequestBody RegisterRequest registerRequest){
        return ResponseEntity.ok(authenticationService.register(registerRequest));
    }*/


}
