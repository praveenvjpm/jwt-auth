// src/pages/LoginPage.js
import React, { useContext, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import API from '../api';
import { AuthContext } from '../context/AuthContext';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { Typography } from '@mui/material';

function LoginPage() {
  const [email, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { setAuthData } = useContext(AuthContext);

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await API.post('/auth/authenticate', { email: email, password });
     const { token, role, firstName, lastName, userName} = response.data;
      setAuthData({ token, role, firstName, lastName, userName });

      console.log('hello world');
      navigate('/home');
      console.log('hello world done');
    } catch (err) {
      console.log(err);
      setError('Invalid credentials');
    }
  };

  return (
  //   <div style={{ maxWidth: 400, margin: '100px auto' }}>
  //     <h2>Login</h2>
  //     <form onSubmit={handleSubmit}>
  //       <div>
  //         <label>Email</label><br/>
  //         <input
  //           type="text"
  //           value={email}
  //           onChange={(e) => setUsername(e.target.value)}
  //           required
  //         />
  //       </div>

  //       <div style={{ marginTop: 10 }}>
  //         <label>Password</label><br/>
  //         <input
  //           type="password"
  //           value={password}
  //           onChange={(e) => setPassword(e.target.value)}
  //           required
  //         />
  //       </div>

  //       <button type="submit" style={{ marginTop: 20 }}>Login</button>
  //     </form>

  //     {error && <p style={{ color: 'red' }}>{error}</p>}
  //   </div>
  // );

  <Container maxWidth="xs">
      <Box sx={{ mt: 6, p: 3, boxShadow: 3, borderRadius: 2, bgcolor: 'background.paper' }}>
        <Typography style={{alignSelf:'center'}}></Typography>
        <form onSubmit={handleSubmit}>
      
<svg  style ={{paddingLeft:'100'}} viewBox="0 0 90 70" >
	<path  d="M28.9647 13.5687C29.8849 12.9703 30.8283 12.553 32.1542 12.5527C35.1952 12.5521 37.6604 15.0148 37.6604 18.052C37.6604 21.0891 35.1952 23.5511 32.1542 23.5511C30.8691 23.5511 29.894 23.1327 28.9647 22.5351L22.0721 18.052L28.9647 13.5687ZM4.21638 43.8988L30.0411 60.6903C32.5584 62.3193 36.0669 61.7306 37.7741 59.0631C39.4362 56.4661 38.7301 53.0234 36.1448 51.34L2.62803 29.5401C2.62803 29.5401 -0.805552 33.7103 0.23567 38.5748C0.977282 42.0396 4.21638 43.8988 4.21638 43.8988Z" fill="#38D200"></path>
	<path  d="M1.62342 18.0384C1.62342 23.556 5.57937 25.9416 5.57937 25.9416L36.1454 45.8223C36.1454 45.8223 39.5348 41.7708 38.5313 36.8528C37.8121 33.328 34.1628 31.2393 34.1628 31.2393L13.888 18.0521L25.7872 10.3133C28.3749 8.63344 29.109 5.17668 27.4269 2.59245C25.7449 0.00822502 22.2839 -0.725041 19.6961 0.954835L5.57779 10.184C5.57779 10.184 1.62342 12.5393 1.62342 18.0384ZM8.69567 60.5642C7.77544 61.1626 6.8321 61.5799 5.50624 61.5802C2.46521 61.5809 0 59.1182 0 56.081C0 53.0439 2.46521 50.5818 5.50624 50.5818C6.79141 50.5818 7.76651 51.0003 8.69567 51.5978L15.5883 56.0809L8.69567 60.5642Z" fill="#0473EA"></path>
</svg>
          
          <Grid container spacing={2} direction="column">
            <Grid item>
              <TextField
                fullWidth
                label="Email"
                variant="outlined"
                name="email"
                type="email"
                required
                value={email}
                onChange={(e) => setUsername(e.target.value)}
              />
            </Grid>
            <Grid item>
              <TextField
                fullWidth
                label="Password"
                variant="outlined"
                name="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </Grid>
            <Grid item>
              <Button fullWidth variant="contained" color="primary" type="submit">
                Login
              </Button>
            </Grid>
          </Grid>
        </form>
      </Box>
    </Container>
  );
}

export default LoginPage;
