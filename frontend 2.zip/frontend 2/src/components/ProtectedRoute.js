import React, { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { jwtDecode } from 'jwt-decode';

function ProtectedRoute({ children }) {
  const { authData, logout } = useContext(AuthContext);
  const token = authData?.token || authData?.accessToken || null;

  // no token -> redirect to login
  if (!token) return <Navigate to="/login" replace />;

  try {
    const decoded = jwtDecode(token);
    const now = Math.floor(Date.now() / 1000);

    // token expired -> clear auth and redirect
    if (decoded?.exp && now >= decoded.exp) {
      logout?.();
      return <Navigate to="/login" replace />;
    }
  } catch (err) {
    // invalid token -> clear auth and redirect
    logout?.();
    return <Navigate to="/login" replace />;
  }

  return children;
}

export default ProtectedRoute;