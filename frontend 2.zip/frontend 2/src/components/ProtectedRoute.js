// src/components/ProtectedRoute.js
import React ,{ useContext, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { jwtDecode } from "jwt-decode";


function ProtectedRoute({ children }) {
    const { authData } = useContext(AuthContext);
    if (!authData ) {
    return <Navigate to="/login" replace />;
  }
    console.log(authData.token)


    const decoded = jwtDecode(authData.token); // { ... , exp: 1721234567 }
    const now = Math.floor(Date.now() / 1000); // current time in seconds
console.log(decoded.exp)
  if (!authData || decoded.exp && now >= decoded.exp) {
    return <Navigate to="/login" replace />;
  }
  return children;
}


export default ProtectedRoute;
