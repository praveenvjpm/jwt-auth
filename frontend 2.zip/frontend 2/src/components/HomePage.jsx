import React, { useEffect, useState,useContext } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import Navbar from '../pages/Navbar';
import { AdminHome } from '../pages/AdminHome';
import { ManagerHome } from '../pages/ManagerHome';
import { UserHome } from '../pages/UserHome';
import { AddUser } from '../pages/AddUser';
import UserProfile from '../pages/UserProfile';
import Request from '../pages/Request';

function HomePage() {
  const [message, setMessage] = useState('');
  const navigate = useNavigate();
  const location = useLocation();
  const { logout,authData } = useContext(AuthContext);


    useEffect(() => {
        //alert(location.state.from)
        if (location.state != null && location.state.from === 'Add Users') {
            setMessage('addUser');
        }
        else if (location.state != null && location.state.from === 'Profile') {
            setMessage('Profile');
        }
        else if (location.state != null && location.state.from === 'Initiate Request') {
            setMessage('Request');
        }
        else{
            setMessage(null);
        }
    }, [location]);

  const handleLogout = () => {
    logout();           // clear co
    // ntext, storage
    navigate('/login');
  };

  return (
    <div >
       <Navbar></Navbar>
        {message != null && message === 'addUser' && <AddUser/>}
        {message != null && message === 'Profile' && <UserProfile/>}
        {message != null && message === 'Request' && <Request/>}
        {message === null && authData.role === 'ADMIN' && <AdminHome/>}
        {message === null && authData.role === 'MANAGER' && <ManagerHome/>}
        {message === null && authData.role === 'USER' && <UserHome/>}
    </div>
  );
}

export default HomePage;
