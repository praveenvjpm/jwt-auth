import React, { createContext, useState } from 'react';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [authData, setAuthData] = useState(() => {
    const saved = localStorage.getItem('authData');
    return saved ? JSON.parse(saved) : null;
  });

  const updateAuthData = (data) => {
    localStorage.setItem('authData', JSON.stringify(data));
    setAuthData(data);
  };

 const logout = () => {
    setAuthData(null);               // Reset context state
    localStorage.removeItem('authData'); // Remove persisted data
    // optionally navigate to login
  };

  return (
    <AuthContext.Provider value={{ authData, setAuthData: updateAuthData , logout}}>
      {children}
    </AuthContext.Provider>
  );
};