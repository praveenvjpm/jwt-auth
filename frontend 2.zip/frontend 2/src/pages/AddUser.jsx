import React, { useState, useContext, useEffect } from 'react';
import {
  Box,
  TextField,
  Button,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
  FormHelperText,
  Typography,
  Alert
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import API from '../api';

export function AddUser() {
  const navigate = useNavigate();
  const { authData } = useContext(AuthContext);
  const currentRole = authData?.role ?? null;

  // Determine allowed roles based on current logged-in user's role
  const allowedRoles = (() => {
    if (currentRole === 'ADMIN') return ['ADMIN', 'MANAGER', 'USER'];
    if (currentRole === 'MANAGER') return ['USER'];
    return [];
  })();

  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    role: allowedRoles[0] ?? ''
  });

  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState('');

  useEffect(() => {
    // keep role in sync if allowedRoles changes (e.g., auth updates)
    if (allowedRoles.length > 0 && !allowedRoles.includes(form.role)) {
      setForm(f => ({ ...f, role: allowedRoles[0] }));
    }
  }, [currentRole, allowedRoles]); // eslint-disable-line

  const emailRegex = /^\S+@\S+\.\S+$/;

  const validate = (values) => {
    const err = {};
    if (!values.firstName?.trim()) err.firstName = 'First name is required';
    if (!values.lastName?.trim()) err.lastName = 'Last name is required';
    if (!values.email?.trim()) err.email = 'Email is required';
    else if (!emailRegex.test(values.email)) err.email = 'Enter a valid email';
    if (!values.role) err.role = 'Role is required';
    return err;
  };

  useEffect(() => {
    // validate on change/touch to enable/disable submit and show errors
    if (Object.keys(touched).length > 0) {
      setErrors(validate(form));
    }
  }, [form, touched]);

  const handleChange = (field) => (e) => {
    const value = e.target.value;
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleBlur = (field) => () => {
    setTouched(prev => ({ ...prev, [field]: true }));
    setErrors(validate(form));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validation = validate(form);
    setErrors(validation);
    setTouched({ firstName: true, lastName: true, email: true, role: true });
    if (Object.keys(validation).length) return;

    if (allowedRoles.length === 0) {
      setErrors({ form: 'You do not have permission to add users.' });
      return;
    }

    setSubmitting(true);
    setErrors({});
    try {
      const token = authData?.token || authData?.accessToken || null;
      const headers = token ? { Authorization: `Bearer ${token}` } : {};

      const response = await API.post('user/addUser', {
        firstName: form.firstName,
        lastName: form.lastName,
        email: form.email,
        role: form.role
      }, { headers });

      if (response?.status === 201) {
        // success: clear form, touched and field errors so no validation messages show
        setSuccess('User added successfully');
        setForm({ firstName: '', lastName: '', email: '', role: allowedRoles[0] ?? '' });
        setErrors({});
        setTouched({});
        // optionally navigate after a delay
        setTimeout(() => navigate('/home'), 1200);
      } else {
        const msg = response?.data?.message || 'Failed to add user';
        setErrors({ form: msg });
      }
    } catch (err) {
      const status = err?.response?.status;
      if (status === 409) {
        setErrors({ form: `User already registered (${status})` });
      } else {
        const message = err?.response?.data?.message || err.message || 'Network error. Please try again.';
        setErrors({ form: message });
      }
      console.error('Create user error:', err);
    } finally {
      setSubmitting(false);
    }
  };

  if (!currentRole) {
    return (
      <Box sx={{ p: 3 }}>
        <Typography variant="h6">Add User</Typography>
        <Alert severity="warning">Unable to determine current user role. Please login again.</Alert>
      </Box>
    );
  }

  if (allowedRoles.length === 0) {
    return (
      <Box sx={{ p: 3 }}>
        <Typography variant="h6">Add User</Typography>
        <Alert severity="info">Your account does not have permission to add users.</Alert>
      </Box>
    );
  }

  return (
    <Box
      component="form"
      onSubmit={handleSubmit}
      sx={{
        maxWidth: 720,
        mx: 'auto',
        p: 3,
        display: 'grid',
        gap: 2,
        background: 'white',
        borderRadius: 1,
      }}
    >
      <Typography variant="h5">Add User</Typography>

      {errors.form && <Alert severity="error">{errors.form}</Alert>}
      {success && <Alert severity="success">{success}</Alert>}

      <TextField
        label="First name"
        value={form.firstName}
        onChange={handleChange('firstName')}
        onBlur={handleBlur('firstName')}
        error={Boolean(touched.firstName && errors.firstName)}
        helperText={touched.firstName ? errors.firstName : ''}
        required
      />

      <TextField
        label="Last name"
        value={form.lastName}
        onChange={handleChange('lastName')}
        onBlur={handleBlur('lastName')}
        error={Boolean(touched.lastName && errors.lastName)}
        helperText={touched.lastName ? errors.lastName : ''}
        required
      />

      <TextField
        label="Email"
        type="email"
        value={form.email}
        onChange={handleChange('email')}
        onBlur={handleBlur('email')}
        error={Boolean(touched.email && errors.email)}
        helperText={touched.email ? errors.email : ''}
        required
      />

      <FormControl error={Boolean(touched.role && errors.role)} required>
        <InputLabel id="role-label">Role</InputLabel>
        <Select
          labelId="role-label"
          value={form.role}
          label="Role"
          onChange={handleChange('role')}
          onBlur={handleBlur('role')}
        >
          {allowedRoles.map(r => (
            <MenuItem key={r} value={r}>{r}</MenuItem>
          ))}
        </Select>
        <FormHelperText>{touched.role ? errors.role : ''}</FormHelperText>
      </FormControl>

      <Box sx={{ display: 'flex', gap: 2, justifyContent: 'flex-end', mt: 1 }}>
        <Button variant="outlined" onClick={() => navigate(-1)} disabled={submitting}>
          Cancel
        </Button>
        <Button variant="contained" type="submit" disabled={submitting || Object.keys(errors).length > 0}>
          {submitting ? 'Creating...' : 'Create User'}
        </Button>
      </Box>
    </Box>
  );
}
