import React, { useState, useEffect, useContext } from 'react';
import {
  Box,
  Typography,
  Tabs,
  Tab,
  Paper,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
  Alert,
} from '@mui/material';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import API from '../api';

export const UserHome = () => {
  const { authData } = useContext(AuthContext);
  const token = authData?.token || authData?.accessToken || null;

  const [tab, setTab] = useState(0); // 0 = active, 1 = completed
  const [loading, setLoading] = useState(false);
  const [activeRequests, setActiveRequests] = useState([]);
  const [completedRequests, setCompletedRequests] = useState([]);
  const [error, setError] = useState('');
  const [selected, setSelected] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    const loadRequests = async () => {
      setLoading(true);
      setError('');
      try {
        if (!API || typeof API !== 'string') throw new Error('API base URL not configured');

        const headers = token ? { Authorization: `Bearer ${token}` } : {};
        // adjust endpoints as your backend expects
        const [activeRes, completedRes] = await Promise.all([
          axios.get(`${API.replace(/\/+$/, '')}/requests?status=active`, { headers }),
          axios.get(`${API.replace(/\/+$/, '')}/requests?status=completed`, { headers }),
        ]);

        const mapReq = (r) =>
          r?.data?.map?.(it => ({
            id: it.id ?? it.requestId,
            user: it.userName ?? it.user ?? `${it.firstName ?? ''} ${it.lastName ?? ''}`.trim(),
            type: it.type ?? it.requestType ?? 'Request',
            details: it.details ?? it.description ?? '',
            status: it.status ?? 'pending',
            createdAt: it.createdAt ?? it.date ?? null,
            raw: it
          })) || [];

        setActiveRequests(mapReq(activeRes));
        setCompletedRequests(mapReq(completedRes));
      } catch (err) {
        console.error('Load requests error', err);
        setError('Failed to load requests. Showing sample data.');
        // fallback sample data
        setActiveRequests([
          { id: 1, user: 'John Doe', type: 'Access Request', details: 'Request to access system', status: 'pending', createdAt: '2025-10-01', raw: {} },
          { id: 2, user: 'Alice Brown', type: 'Role Change', details: 'Request to become Manager', status: 'pending', createdAt: '2025-10-03', raw: {} },
        ]);
        setCompletedRequests([
          { id: 11, user: 'Jane Smith', type: 'Access Request', details: 'Access granted', status: 'completed', createdAt: '2025-09-20', raw: {} },
        ]);
      } finally {
        setLoading(false);
      }
    };

    loadRequests();
  }, [token]);

  const handleTab = (e, val) => setTab(val);

  const openDetails = (req) => {
    setSelected(req);
    setDialogOpen(true);
  };

  const closeDetails = () => {
    setDialogOpen(false);
    setSelected(null);
  };

  const markComplete = async (req) => {
    if (!req) return;
    setActionLoading(true);
    try {
      if (!API || typeof API !== 'string') throw new Error('API base URL not configured');

      const headers = token ? { Authorization: `Bearer ${token}` } : {};
      await axios.post(`${API.replace(/\/+$/, '')}/requests/${req.id}/complete`, {}, { headers });
      // update local state
      setActiveRequests(prev => prev.filter(p => p.id !== req.id));
      setCompletedRequests(prev => [{ ...req, status: 'completed' }, ...prev]);
    } catch (err) {
      console.error('Complete request error', err);
      setError('Failed to mark request complete.');
    } finally {
      setActionLoading(false);
    }
  };

  const renderTable = (rows, showCompleteAction = false) => {
    if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}><CircularProgress /></Box>;
    if (!rows.length) return <Typography sx={{ p: 2 }}>No requests.</Typography>;

    return (
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>ID</TableCell>
            <TableCell>Type</TableCell>
            <TableCell>Details</TableCell>
            <TableCell>Created</TableCell>
            <TableCell>Status</TableCell>
            <TableCell align="right">Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map(r => (
            <TableRow key={r.id}>
              <TableCell>{r.id}</TableCell>
              <TableCell>{r.type}</TableCell>
              <TableCell style={{ maxWidth: 360, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.details}</TableCell>
              <TableCell>{r.createdAt ?? '-'}</TableCell>
              <TableCell>{r.status}</TableCell>
              <TableCell align="right">
                <Button size="small" onClick={() => openDetails(r)}>View</Button>
                {showCompleteAction && (
                  <Button size="small" color="primary" onClick={() => markComplete(r)} disabled={actionLoading} sx={{ ml: 1 }}>
                    Mark Complete
                  </Button>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    );
  };

  return (
    <Box sx={{ maxWidth: 1100, mx: 'auto', p: 3 }}>
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="h5">My Requests</Typography>
        <Typography variant="body2" color="text.secondary">View your active and completed requests.</Typography>
      </Paper>

      {error && <Alert severity="warning" sx={{ mb: 2 }}>{error}</Alert>}

      <Paper>
        <Tabs value={tab} onChange={handleTab} indicatorColor="primary" textColor="primary">
          <Tab label={`Active (${activeRequests.length})`} />
          <Tab label={`Completed (${completedRequests.length})`} />
        </Tabs>

        <Box sx={{ p: 2 }}>
          {tab === 0 && renderTable(activeRequests, true)}
          {tab === 1 && renderTable(completedRequests, false)}
        </Box>
      </Paper>

      <Dialog open={dialogOpen} onClose={closeDetails} fullWidth maxWidth="sm">
        <DialogTitle>Request details</DialogTitle>
        <DialogContent dividers>
          {selected ? (
            <Box sx={{ display: 'grid', gap: 1 }}>
              <Typography><strong>ID:</strong> {selected.id}</Typography>
              <Typography><strong>User:</strong> {selected.user}</Typography>
              <Typography><strong>Type:</strong> {selected.type}</Typography>
              <Typography><strong>Status:</strong> {selected.status}</Typography>
              <Typography><strong>Created:</strong> {selected.createdAt}</Typography>
              <Typography sx={{ mt: 1 }}>{selected.details}</Typography>
              <pre style={{ whiteSpace: 'pre-wrap', background: '#f7f7f7', padding: 8, borderRadius: 4 }}>{JSON.stringify(selected.raw ?? {}, null, 2)}</pre>
            </Box>
          ) : (
            <CircularProgress />
          )}
        </DialogContent>
        <DialogActions>
          {selected?.status !== 'completed' && (
            <Button onClick={() => { markComplete(selected); closeDetails(); }} disabled={actionLoading}>Mark Complete</Button>
          )}
          <Button onClick={closeDetails}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default UserHome;
