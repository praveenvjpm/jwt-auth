import React, { useState, useContext, useEffect } from 'react';
import {
  Box,
  TextField,
  Button,
  Typography,
  Alert,
  Divider,
  IconButton,
  InputAdornment
} from '@mui/material';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { AuthContext } from '../context/AuthContext';
import API from '../api';

export default function UserProfile() {
  const { authData } = useContext(AuthContext);
  const initialFirst = authData?.firstName ?? '';
  const initialLast = authData?.lastName ?? '';
  const initialEmail = authData?.userName ?? '';

  const [profile, setProfile] = useState({
    firstName: initialFirst,
    lastName: initialLast,
    email: initialEmail
  });
  const [profileErrors, setProfileErrors] = useState({});
  const [profileTouched, setProfileTouched] = useState({});
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileSuccess, setProfileSuccess] = useState('');

  const [pw, setPw] = useState({
    current: '',
    newPassword: '',
    confirm: ''
  });
  const [pwErrors, setPwErrors] = useState({});
  const [showPw, setShowPw] = useState({ current: false, newPassword: false, confirm: false });
  const [changingPw, setChangingPw] = useState(false);
  const [pwSuccess, setPwSuccess] = useState('');

  // Names: letters only, optional single space between two words
  const nameRegex = /^[A-Za-z]+(?: [A-Za-z]+)?$/;
  const emailRegex = /^\S+@\S+\.\S+$/;

  useEffect(() => {
    // keep email readonly in profile if provided by auth (optional)
  }, []);

  const sanitizeName = (v) => {
    let value = v.replace(/[^A-Za-z\s]/g, '');
    value = value.replace(/\s+/g, ' ').trimStart();
    const parts = value.split(' ');
    if (parts.length > 2) value = parts.slice(0, 2).join(' ');
    return value;
  };

  const validateProfile = (vals) => {
    const e = {};
    if (!vals.firstName?.trim()) e.firstName = 'First name required';
    else if (!nameRegex.test(vals.firstName.trim())) e.firstName = 'Only letters allowed; at most one space';
    if (!vals.lastName?.trim()) e.lastName = 'Last name required';
    else if (!nameRegex.test(vals.lastName.trim())) e.lastName = 'Only letters allowed; at most one space';
    if (!vals.email?.trim()) e.email = 'Email required';
    else if (!emailRegex.test(vals.email)) e.email = 'Enter a valid email';
    return e;
  };

  const validatePw = (vals) => {
    const e = {};
    if (!vals.current) e.current = 'Current password required';
    if (!vals.newPassword) e.newPassword = 'New password required';
    else if (vals.newPassword.length < 8) e.newPassword = 'Minimum 8 characters';
    if (!vals.confirm) e.confirm = 'Please confirm new password';
    else if (vals.newPassword !== vals.confirm) e.confirm = 'Passwords do not match';
    return e;
  };

  const handleProfileChange = (field) => (ev) => {
    const val = field === 'firstName' || field === 'lastName' ? sanitizeName(ev.target.value) : ev.target.value;
    setProfile(prev => ({ ...prev, [field]: val }));
    setProfileTouched(prev => ({ ...prev, [field]: true }));
    setProfileErrors(validateProfile({ ...profile, [field]: val }));
  };

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    const errors = validateProfile(profile);
    setProfileErrors(errors);
    setProfileTouched({ firstName: true, lastName: true, email: true });
    if (Object.keys(errors).length) return;
    setSavingProfile(true);
    try {
      // TODO: call API to save profile
      await new Promise(r => setTimeout(r, 600));
      setProfileSuccess('Profile updated');
      setTimeout(() => setProfileSuccess(''), 2000);
    } catch {
      setProfileErrors({ form: 'Failed to save. Try again.' });
    } finally {
      setSavingProfile(false);
    }
  };

  const handlePwChange = (field) => (ev) => {
    setPw(prev => ({ ...prev, [field]: ev.target.value }));
    setPwErrors(validatePw({ ...pw, [field]: ev.target.value }));
  };

  const handleToggleShow = (field) => () => {
    setShowPw(prev => ({ ...prev, [field]: !prev[field] }));
  };

  const handlePwSubmit = async (e) => {
    e.preventDefault();
    const errors = validatePw(pw);
    setPwErrors(errors);
    if (Object.keys(errors).length) return;

    const token = authData?.token || authData?.accessToken || null;
    if (!token) {
      setPwErrors({ form: 'Not authenticated. Please login again.' });
      return;
    }

    setChangingPw(true);
    setPwErrors({});
    try {
      const payload = {
        firstName: profile.firstName,
        lastName: profile.lastName,
        email: profile.email,
        password: pw.current,
        newPassword: pw.newPassword
      };

      // use API.post (axios instance) to call backend
      const response = await API.post('/user/changePassword', payload, {
        headers: { Authorization: `Bearer ${token}` }
      });

      const data = response?.data ?? {};

      if (response.status >= 200 && response.status < 300) {
        setPw({ current: '', newPassword: '', confirm: '' });
        setPwSuccess(data.message || 'Password changed successfully');
        setTimeout(() => setPwSuccess(''), 3000);
      } else {
        setPwErrors({ form: data.message || 'Failed to change password' });
      }
    } catch (err) {
      const message = err?.response?.data?.message || err.message || 'Network error. Please try again.';
      setPwErrors({ form: message });
      console.error('Change password error:', err);
    } finally {
      setChangingPw(false);
    }
  };

  // Make profile fields read-only
  const profileReadOnly = true;

  return (
    <Box sx={{ maxWidth: 880, mx: 'auto', p: 3, display: 'grid', gap: 3 }}>
      <Typography variant="h5">User Profile</Typography>

      <Box component="form" onSubmit={handleProfileSubmit} sx={{ display: 'grid', gap: 2, background: 'white', p: 2, borderRadius: 1 }}>
        <Typography variant="h6">Profile</Typography>

        {profileErrors.form && <Alert severity="error">{profileErrors.form}</Alert>}
        {profileSuccess && <Alert severity="success">{profileSuccess}</Alert>}

        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2 }}>
          <TextField
            label="First name"
            value={profile.firstName}
            InputProps={{ readOnly: true }}
            error={Boolean(profileErrors.firstName)}
            helperText={profileErrors.firstName || ''}
            required
            fullWidth
          />

          <TextField
            label="Last name"
            value={profile.lastName}
            InputProps={{ readOnly: true }}
            error={Boolean(profileErrors.lastName)}
            helperText={profileErrors.lastName || ''}
            required
            fullWidth
          />
        </Box>

        <TextField
          label="Email"
          value={profile.email}
          InputProps={{ readOnly: true }}
          error={Boolean(profileErrors.email)}
          helperText={profileErrors.email || ''}
          required
          type="email"
          fullWidth
        />

   
      </Box>

      <Divider />

      <Box component="form" onSubmit={handlePwSubmit} sx={{ display: 'grid', gap: 2, background: 'white', p: 2, borderRadius: 1 }}>
        <Typography variant="h6">Change Password</Typography>

        {pwErrors.form && <Alert severity="error">{pwErrors.form}</Alert>}
        {pwSuccess && <Alert severity="success">{pwSuccess}</Alert>}

        <TextField
          label="Current password"
          type={showPw.current ? 'text' : 'password'}
          value={pw.current}
          onChange={handlePwChange('current')}
          required
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton onClick={handleToggleShow('current')} edge="end" size="small">
                  {showPw.current ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            )
          }}
          error={Boolean(pwErrors.current)}
          helperText={pwErrors.current || ''}
        />

        <TextField
          label="New password"
          type={showPw.newPassword ? 'text' : 'password'}
          value={pw.newPassword}
          onChange={handlePwChange('newPassword')}
          required
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton onClick={handleToggleShow('newPassword')} edge="end" size="small">
                  {showPw.newPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            )
          }}
          error={Boolean(pwErrors.newPassword)}
          helperText={pwErrors.newPassword || 'Minimum 8 characters'}
        />

        <TextField
          label="Confirm new password"
          type={showPw.confirm ? 'text' : 'password'}
          value={pw.confirm}
          onChange={handlePwChange('confirm')}
          required
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton onClick={handleToggleShow('confirm')} edge="end" size="small">
                  {showPw.confirm ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            )
          }}
          error={Boolean(pwErrors.confirm)}
          helperText={pwErrors.confirm || ''}
        />

        <Box sx={{ display: 'flex', gap: 2, justifyContent: 'flex-end' }}>
          <Button variant="outlined" onClick={() => { setPw({ current: '', newPassword: '', confirm: '' }); setPwErrors({}); }} disabled={changingPw}>
            Reset
          </Button>
          <Button variant="contained" type="submit" disabled={changingPw || Object.keys(pwErrors).length > 0}>
            {changingPw ? 'Changing...' : 'Change Password'}
          </Button>
        </Box>
      </Box>
    </Box>
  );
}
