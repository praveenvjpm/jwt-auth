import React, { useState, useEffect, useContext } from 'react';
import {
  Box,
  Grid,
  TextField,
  Button,
  MenuItem,
  Typography,
  Alert,
  CircularProgress,
  Paper,
  Divider,
  Card,
  CardContent,
  Stack
} from '@mui/material';
import API from '../api';
import { AuthContext } from '../context/AuthContext';

export default function Request() {
  const { authData } = useContext(AuthContext);
  const token = authData?.token || authData?.accessToken || null;

  const [partners, setPartners] = useState([]);
  const [loadingPartners, setLoadingPartners] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [serverMsg, setServerMsg] = useState({ type: '', text: '' });

  const [form, setForm] = useState({
    FK_PARTNER_CODE: '',
    MIN_LOAN_VALUE: '',
    MAX_LOAN_VALUE: '',
    TENOR_ALL_INTEREST_RATE: '',
    TENOR_1_INTEREST_RATE: '',
    TENOR_2_INTEREST_RATE: '',
    TENOR_3_INTEREST_RATE: '',
    TENOR_6_INTEREST_RATE: '',
    TENOR_12_INTEREST_RATE: '',
    MAXIMUM_TENOR: '',
    VALID_TENORS: '',
    MIN_MONTHLY_INCCOME: '',
    MAX_MONTHLY_INCCOME: '',
    MIN_AGE_YRS: '',
    MAX_AGE_YRS: '',
    MIDDLE_NAME_MAX_LENGTH: '',
    PARTNER_ADMIN_FEE: '',
    PARTNER_ADMIN_FEE_PERCENT: '',
    CUSTOMER_SEGMENT: '',
    LOAN_TYPE: '',
    PHONE_NUMBER: '',
    VAT_METHOD: '',
    SCORE: '',
    RES_ADDRESS: '',
    LOAN_PRODUCER: '',
    EFFECTIVE_DATE: '',
    JOB_TITLE: '',
    OCCUPATION_CODE: '',
    COMPANY_NAME: '',
    LOAN_SEGMENT: ''
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    const loadPartners = async () => {
      setLoadingPartners(true);
      try {
        const headers = token ? { Authorization: `Bearer ${token}` } : {};
        const res = await API.get('/partners', { headers });
        const data = res?.data ?? [];
        const opts = Array.isArray(data)
          ? data.map((p) => (typeof p === 'string' ? { code: p, name: p } : { code: p.code ?? p.id ?? p.value, name: p.name ?? p.label ?? p.code }))
          : [];
        setPartners(opts);
      } catch (err) {
        console.error('Failed to load partners', err);
        setPartners([
          { code: 'P001', name: 'Partner A' },
          { code: 'P002', name: 'Partner B' }
        ]);
      } finally {
        setLoadingPartners(false);
      }
    };

    loadPartners();
  }, [token]);

  const handleChange = (field) => (e) => {
    setForm((s) => ({ ...s, [field]: e.target.value }));
    setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const validate = () => {
    const e = {};
    if (!form.FK_PARTNER_CODE) e.FK_PARTNER_CODE = 'Partner is required';
    if (!form.MIN_LOAN_VALUE) e.MIN_LOAN_VALUE = 'Min loan value is required';
    if (!form.MAX_LOAN_VALUE) e.MAX_LOAN_VALUE = 'Max loan value is required';
    if (form.MIN_LOAN_VALUE && form.MAX_LOAN_VALUE && Number(form.MIN_LOAN_VALUE) > Number(form.MAX_LOAN_VALUE)) {
      e.MAX_LOAN_VALUE = 'Max must be >= Min';
    }
    if (!form.EFFECTIVE_DATE) e.EFFECTIVE_DATE = 'Effective date is required';
    const numericFields = [
      'MIN_LOAN_VALUE','MAX_LOAN_VALUE','TENOR_ALL_INTEREST_RATE','TENOR_1_INTEREST_RATE',
      'TENOR_2_INTEREST_RATE','TENOR_3_INTEREST_RATE','TENOR_6_INTEREST_RATE','TENOR_12_INTEREST_RATE',
      'MIN_MONTHLY_INCCOME','MAX_MONTHLY_INCCOME','PARTNER_ADMIN_FEE','PARTNER_ADMIN_FEE_PERCENT'
    ];
    numericFields.forEach((f) => {
      if (form[f] !== '' && isNaN(Number(form[f]))) e[f] = 'Must be a number';
    });
    const intFields = ['MAXIMUM_TENOR','MIN_AGE_YRS','MAX_AGE_YRS','MIDDLE_NAME_MAX_LENGTH'];
    intFields.forEach((f) => {
      if (form[f] !== '' && !Number.isInteger(Number(form[f]))) e[f] = 'Must be an integer';
    });
    return e;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    setServerMsg({ type: '', text: '' });
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length) return;

    setSubmitting(true);
    try {
      const payload = {
        ...form,
        MIN_LOAN_VALUE: form.MIN_LOAN_VALUE ? Number(form.MIN_LOAN_VALUE) : null,
        MAX_LOAN_VALUE: form.MAX_LOAN_VALUE ? Number(form.MAX_LOAN_VALUE) : null,
        TENOR_ALL_INTEREST_RATE: form.TENOR_ALL_INTEREST_RATE ? Number(form.TENOR_ALL_INTEREST_RATE) : null,
        TENOR_1_INTEREST_RATE: form.TENOR_1_INTEREST_RATE ? Number(form.TENOR_1_INTEREST_RATE) : null,
        TENOR_2_INTEREST_RATE: form.TENOR_2_INTEREST_RATE ? Number(form.TENOR_2_INTEREST_RATE) : null,
        TENOR_3_INTEREST_RATE: form.TENOR_3_INTEREST_RATE ? Number(form.TENOR_3_INTEREST_RATE) : null,
        TENOR_6_INTEREST_RATE: form.TENOR_6_INTEREST_RATE ? Number(form.TENOR_6_INTEREST_RATE) : null,
        TENOR_12_INTEREST_RATE: form.TENOR_12_INTEREST_RATE ? Number(form.TENOR_12_INTEREST_RATE) : null,
        MAXIMUM_TENOR: form.MAXIMUM_TENOR ? Number(form.MAXIMUM_TENOR) : null,
        MIN_MONTHLY_INCCOME: form.MIN_MONTHLY_INCCOME ? Number(form.MIN_MONTHLY_INCCOME) : null,
        MAX_MONTHLY_INCCOME: form.MAX_MONTHLY_INCCOME ? Number(form.MAX_MONTHLY_INCCOME) : null,
        MIN_AGE_YRS: form.MIN_AGE_YRS ? Number(form.MIN_AGE_YRS) : null,
        MAX_AGE_YRS: form.MAX_AGE_YRS ? Number(form.MAX_AGE_YRS) : null,
        MIDDLE_NAME_MAX_LENGTH: form.MIDDLE_NAME_MAX_LENGTH ? Number(form.MIDDLE_NAME_MAX_LENGTH) : null,
        PARTNER_ADMIN_FEE: form.PARTNER_ADMIN_FEE ? Number(form.PARTNER_ADMIN_FEE) : null,
        PARTNER_ADMIN_FEE_PERCENT: form.PARTNER_ADMIN_FEE_PERCENT ? Number(form.PARTNER_ADMIN_FEE_PERCENT) : null,
        EFFECTIVE_DATE: form.EFFECTIVE_DATE
      };

      const headers = token ? { Authorization: `Bearer ${token}` } : {};
      const res = await API.post('/rates', payload, { headers });

      if (res.status === 201 || res.status === 200) {
        setServerMsg({ type: 'success', text: 'Record created successfully' });
        setForm({
          FK_PARTNER_CODE: '',
          MIN_LOAN_VALUE: '',
          MAX_LOAN_VALUE: '',
          TENOR_ALL_INTEREST_RATE: '',
          TENOR_1_INTEREST_RATE: '',
          TENOR_2_INTEREST_RATE: '',
          TENOR_3_INTEREST_RATE: '',
          TENOR_6_INTEREST_RATE: '',
          TENOR_12_INTEREST_RATE: '',
          MAXIMUM_TENOR: '',
          VALID_TENORS: '',
          MIN_MONTHLY_INCCOME: '',
          MAX_MONTHLY_INCCOME: '',
          MIN_AGE_YRS: '',
          MAX_AGE_YRS: '',
          MIDDLE_NAME_MAX_LENGTH: '',
          PARTNER_ADMIN_FEE: '',
          PARTNER_ADMIN_FEE_PERCENT: '',
          CUSTOMER_SEGMENT: '',
          LOAN_TYPE: '',
          PHONE_NUMBER: '',
          VAT_METHOD: '',
          SCORE: '',
          RES_ADDRESS: '',
          LOAN_PRODUCER: '',
          EFFECTIVE_DATE: '',
          JOB_TITLE: '',
          OCCUPATION_CODE: '',
          COMPANY_NAME: '',
          LOAN_SEGMENT: ''
        });
        setErrors({});
      } else {
        setServerMsg({ type: 'error', text: res?.data?.message || 'Failed to create record' });
      }
    } catch (err) {
      console.error('Create rates error', err);
      const status = err?.response?.status;
      if (status === 409) setServerMsg({ type: 'error', text: 'Record already exists (409)' });
      else setServerMsg({ type: 'error', text: err?.response?.data?.message || 'Network error' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Paper component="form" onSubmit={handleSubmit} sx={{ p: { xs: 2, md: 4 }, maxWidth: 1100, mx: 'auto', bgcolor: '#fafafa' }}>
      <Typography variant="h5" sx={{ mb: 1 }}>Create Loan Rate</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Fill required fields and submit. Fields marked * are required.
      </Typography>

      {serverMsg.text && (
        <Alert severity={serverMsg.type === 'success' ? 'success' : 'error'} sx={{ mb: 2 }}>
          {serverMsg.text}
        </Alert>
      )}

      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Card variant="outlined" sx={{ bgcolor: 'white' }}>
            <CardContent>
              <Typography variant="subtitle1" sx={{ mb: 2 }}>Partner & Loan range</Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  {loadingPartners ? (
                    <Stack direction="row" spacing={1} alignItems="center">
                      <CircularProgress size={18} /> <Typography variant="body2">Loading partners</Typography>
                    </Stack>
                  ) : (
                    <TextField
                      select
                      label="Partner Code *"
                      value={form.FK_PARTNER_CODE}
                      onChange={handleChange('FK_PARTNER_CODE')}
                      error={Boolean(errors.FK_PARTNER_CODE)}
                      helperText={errors.FK_PARTNER_CODE}
                      fullWidth
                      variant="outlined"
                    >
                      {partners.map((p) => (
                        <MenuItem key={p.code} value={p.code}>
                          {p.name} ({p.code})
                        </MenuItem>
                      ))}
                    </TextField>
                  )}
                </Grid>

                <Grid item xs={12} sm={3}>
                  <TextField
                    label="Min Loan Value *"
                    value={form.MIN_LOAN_VALUE}
                    onChange={handleChange('MIN_LOAN_VALUE')}
                    error={Boolean(errors.MIN_LOAN_VALUE)}
                    helperText={errors.MIN_LOAN_VALUE}
                    fullWidth
                    variant="outlined"
                    inputProps={{ inputMode: 'numeric' }}
                  />
                </Grid>

                <Grid item xs={12} sm={3}>
                  <TextField
                    label="Max Loan Value *"
                    value={form.MAX_LOAN_VALUE}
                    onChange={handleChange('MAX_LOAN_VALUE')}
                    error={Boolean(errors.MAX_LOAN_VALUE)}
                    helperText={errors.MAX_LOAN_VALUE}
                    fullWidth
                    variant="outlined"
                    inputProps={{ inputMode: 'numeric' }}
                  />
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12}>
          <Card variant="outlined" sx={{ bgcolor: 'white' }}>
            <CardContent>
              <Typography variant="subtitle1" sx={{ mb: 2 }}>Interest Rates</Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <TextField
                    label="Tenor All Interest Rate"
                    value={form.TENOR_ALL_INTEREST_RATE}
                    onChange={handleChange('TENOR_ALL_INTEREST_RATE')}
                    error={Boolean(errors.TENOR_ALL_INTEREST_RATE)}
                    helperText={errors.TENOR_ALL_INTEREST_RATE}
                    fullWidth
                    variant="outlined"
                    inputProps={{ step: '0.01', inputMode: 'decimal' }}
                  />
                </Grid>

                <Grid item xs={12} sm={3}>
                  <TextField label="Tenor 1" value={form.TENOR_1_INTEREST_RATE} onChange={handleChange('TENOR_1_INTEREST_RATE')} fullWidth variant="outlined" inputProps={{ step: '0.01', inputMode: 'decimal' }} />
                </Grid>
                <Grid item xs={12} sm={3}>
                  <TextField label="Tenor 2" value={form.TENOR_2_INTEREST_RATE} onChange={handleChange('TENOR_2_INTEREST_RATE')} fullWidth variant="outlined" inputProps={{ step: '0.01', inputMode: 'decimal' }} />
                </Grid>

                <Grid item xs={12} sm={4}>
                  <TextField label="Tenor 3" value={form.TENOR_3_INTEREST_RATE} onChange={handleChange('TENOR_3_INTEREST_RATE')} fullWidth variant="outlined" inputProps={{ step: '0.01', inputMode: 'decimal' }} />
                </Grid>

                <Grid item xs={12} sm={4}>
                  <TextField label="Tenor 6" value={form.TENOR_6_INTEREST_RATE} onChange={handleChange('TENOR_6_INTEREST_RATE')} fullWidth variant="outlined" inputProps={{ step: '0.01', inputMode: 'decimal' }} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <TextField label="Tenor 12" value={form.TENOR_12_INTEREST_RATE} onChange={handleChange('TENOR_12_INTEREST_RATE')} fullWidth variant="outlined" inputProps={{ step: '0.01', inputMode: 'decimal' }} />
                </Grid>

                <Grid item xs={12} sm={6}>
                  <TextField label="Maximum Tenor" value={form.MAXIMUM_TENOR} onChange={handleChange('MAXIMUM_TENOR')} fullWidth variant="outlined" inputProps={{ inputMode: 'numeric' }} />
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12}>
          <Card variant="outlined" sx={{ bgcolor: 'white' }}>
            <CardContent>
              <Typography variant="subtitle1" sx={{ mb: 2 }}>Additional Info</Typography>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <TextField label="Valid Tenors" value={form.VALID_TENORS} onChange={handleChange('VALID_TENORS')} fullWidth variant="outlined" />
                </Grid>

                <Grid item xs={12} sm={6}>
                  <TextField label="Min Monthly Income" value={form.MIN_MONTHLY_INCCOME} onChange={handleChange('MIN_MONTHLY_INCCOME')} fullWidth variant="outlined" inputProps={{ step: '0.01', inputMode: 'decimal' }} />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Max Monthly Income" value={form.MAX_MONTHLY_INCCOME} onChange={handleChange('MAX_MONTHLY_INCCOME')} fullWidth variant="outlined" inputProps={{ step: '0.01', inputMode: 'decimal' }} />
                </Grid>

                <Grid item xs={12} sm={4}>
                  <TextField label="Min Age (yrs)" value={form.MIN_AGE_YRS} onChange={handleChange('MIN_AGE_YRS')} fullWidth variant="outlined" inputProps={{ inputMode: 'numeric' }} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <TextField label="Max Age (yrs)" value={form.MAX_AGE_YRS} onChange={handleChange('MAX_AGE_YRS')} fullWidth variant="outlined" inputProps={{ inputMode: 'numeric' }} />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <TextField label="Middle name max length" value={form.MIDDLE_NAME_MAX_LENGTH} onChange={handleChange('MIDDLE_NAME_MAX_LENGTH')} fullWidth variant="outlined" inputProps={{ inputMode: 'numeric' }} />
                </Grid>

                <Grid item xs={12} sm={6}>
                  <TextField label="Partner Admin Fee" value={form.PARTNER_ADMIN_FEE} onChange={handleChange('PARTNER_ADMIN_FEE')} fullWidth variant="outlined" inputProps={{ step: '0.01', inputMode: 'decimal' }} />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Admin Fee Percent" value={form.PARTNER_ADMIN_FEE_PERCENT} onChange={handleChange('PARTNER_ADMIN_FEE_PERCENT')} fullWidth variant="outlined" inputProps={{ step: '0.01', inputMode: 'decimal' }} />
                </Grid>

                <Grid item xs={12} sm={6}>
                  <TextField label="Effective Date *" type="datetime-local" value={form.EFFECTIVE_DATE} onChange={handleChange('EFFECTIVE_DATE')} fullWidth variant="outlined" InputLabelProps={{ shrink: true }} error={Boolean(errors.EFFECTIVE_DATE)} helperText={errors.EFFECTIVE_DATE} />
                </Grid>

                <Grid item xs={12} sm={6}>
                  <TextField label="Phone Number" value={form.PHONE_NUMBER} onChange={handleChange('PHONE_NUMBER')} fullWidth variant="outlined" />
                </Grid>

                <Grid item xs={12} sm={6}>
                  <TextField label="Company Name" value={form.COMPANY_NAME} onChange={handleChange('COMPANY_NAME')} fullWidth variant="outlined" />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Loan Segment" value={form.LOAN_SEGMENT} onChange={handleChange('LOAN_SEGMENT')} fullWidth variant="outlined" />
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12}>
          <Divider sx={{ mb: 2 }} />
          <Box sx={{ display: 'flex', gap: 2, justifyContent: 'flex-end' }}>
            <Button variant="outlined" color="inherit" onClick={() => { setForm((f) => Object.keys(f).reduce((acc, k) => ({ ...acc, [k]: '' }), {})); setErrors({}); setServerMsg({ type: '', text: '' }); }}>
              Reset
            </Button>
            <Button variant="contained" type="submit" disabled={submitting} sx={{ minWidth: 140 }}>
              {submitting ? <CircularProgress size={18} color="inherit" /> : 'Create'}
            </Button>
          </Box>
        </Grid>
      </Grid>
    </Paper>
  );
}