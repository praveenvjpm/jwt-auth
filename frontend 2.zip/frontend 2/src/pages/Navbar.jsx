import React, { useContext } from 'react';
import { AppBar, Toolbar, Button, Stack } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import Typography from '@mui/material/Typography';

const menuItems = [
  { label: 'Home', path: '/home', roles: ['USER', 'ADMIN','MANAGER'] },
  { label: 'Active Users', path: '/dashboard', roles: ['ADMIN','MANAGER'] },
  { label: 'Add Managers', path: '/addManagers', roles: ['ADMIN'] },
  { label: 'Add Users', path: '/home', roles: ['ADMIN','MANAGER'] },  
  { label: 'Initiate Request', path: '/home', roles: ['USER'] },
  { label: 'Profile', path: '/home', roles: ['USER', 'ADMIN','MANAGER'] },
  { label: 'Settings', path: '/settings', roles: ['ADMIN'] }
];



export default function Navbar() {
  const { authData } = useContext(AuthContext);  // Assume roles = ['user'] or ['admin']
  const navigate = useNavigate();

  const { logout } = useContext(AuthContext);

  const handleLogout = () => {
      logout();           // clear co
      // ntext, storage
      navigate('/login');
    };

  // Filter menu items allowed for the user's role(s)
  const allowedMenuItems = menuItems.filter(item =>
    item.roles.some(roles => roles.includes(authData.role))
  );

  return (
    <AppBar position="static">


      <Toolbar sx={{ justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h6" component="div" sx={{ textAlign: 'left', alignSelf: 'center' }}>
            LCS GS MANAGEMENT TOOL
        </Typography>
        <Stack direction="row" spacing={2} sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
          {allowedMenuItems.map(item => (
            <Button
              key={item.label}
              color="inherit"
              onClick={() => {
                // when navigating to Home from "Add Users", pass payload via location.state
                if (item.label === 'Add Users' || item.label === 'Profile' || item.label === 'Initiate Request') {
                  navigate(item.path, {
                    state: {
                      from: item.label,
                      payload: {
                        source: 'Navbar',
                        action: 'openAddUser',
                        timestamp: Date.now(),
                        // any initial data you want to pass:
                        initial: { role: 'User', prefillEmail: '' }
                      }
                    }
                  });
                }
                 else {
                  navigate(item.path,{ state: null });
                }
              }}
              sx={{cursor: 'pointer', backgroundColor:'#277BCF','&:hover': {
          backgroundColor: '#27CFBB', // Background color on hover
          color: 'black', // Text color on hover
        },}}
            >
              {item.label}
            </Button>
          ))}
          <Button color="inherit" onClick={handleLogout} sx={{cursor: 'pointer',backgroundColor:'GREY','&:hover': {
          backgroundColor: 'red', // Background color on hover
          color: 'black', // Text color on hover
        },}}>
          Logout
        </Button>
        </Stack>
      </Toolbar>
    </AppBar>
  );
}
