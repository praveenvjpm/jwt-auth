import React, { useState, useEffect, useContext } from 'react';
import {
  DataGrid,
  GridActionsCellItem,
} from '@mui/x-data-grid';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Typography,
  Box,
} from '@mui/material';
import VisibilityIcon from '@mui/icons-material/Visibility';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import API from '../api';

export const ManagerHome = () => {
  // Sample Data
  const [pendingRequests] = useState([
    { id: 1, user: 'John Doe', type: 'Access Request', details: 'Request to access system', status: 'pending' },
    { id: 2, user: 'Jane Smith', type: 'Role Change', details: 'Request to change role', status: 'pending' },
  ]);
  const [activeUsers, setActiveUsers] = useState([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [loadError, setLoadError] = useState('');

  const { authData } = useContext(AuthContext);

  useEffect(() => {
    // load active users from API
    const loadActiveUsers = async () => {
      setLoadingUsers(true);
      setLoadError('');
      try {
        const token = authData?.token || authData?.accessToken || null;
        const headers = token ? { Authorization: `Bearer ${token}` } : {};

         const res = await API.post('user/listUser', {}, { headers });
         
        const data = res?.data ?? [];
        // If backend returns object with users array, adapt:
        const usersArray = Array.isArray(data) ? data : data?.users ?? [];
        // Normalize to expected shape (id, name, email, role, active)
        const normalized = usersArray.map((u, idx) => ({
          id: u.id ?? u.userId ?? idx + 1,
          name: u.name ?? `${u.firstName ?? ''} ${u.lastName ?? ''}`.trim(),
          email: u.email ?? u.userName ?? '',
          role: u.role ?? u.userRole ?? 'User',
          active: typeof u.active === 'boolean' ? u.active : u.isActive ?? true
        }));
        setActiveUsers(normalized);
      } catch (err) {
        console.error('Failed to load active users', err);
        setLoadError('Failed to load active users. Please try again.');
      } finally {
        setLoadingUsers(false);
      }
    };

    // only call if user is authenticated (optional)
    if (authData) loadActiveUsers();
  }, [authData]);

  // State for Request Dialog
  const [openRequestDialog, setOpenRequestDialog] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [rejecting, setRejecting] = useState(false);
  const [rejectComment, setRejectComment] = useState('');

  // State for User Dialog
  const [openUserDialog, setOpenUserDialog] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);

  // Handlers for Requests
  const handleRequestClick = (params) => {
    setSelectedRequest(params.row);
    setRejecting(false);
    setRejectComment('');
    setOpenRequestDialog(true);
  };

  const handleApprove = () => {
    alert(`Approved request ID ${selectedRequest.id}`);
    setOpenRequestDialog(false);
  };

  const handleReject = () => {
    if (!rejecting) {
      setRejecting(true);
    } else {
      alert(`Rejected request ID ${selectedRequest.id} with comment: ${rejectComment}`);
      setOpenRequestDialog(false);
    }
  };

  const handleRequestClose = () => setOpenRequestDialog(false);

  // Handlers for Users
  const handleUserClick = (params) => {
    setSelectedUser(params.row);
    setOpenUserDialog(true);
  };

  const toggleUserActive = () => {
    setActiveUsers((users) =>
      users.map((user) =>
        user.id === selectedUser.id ? { ...user, active: !user.active } : user
      )
    );
    setOpenUserDialog(false);
  };

  const handleUserClose = () => setOpenUserDialog(false);

  // Columns for Requests
  const requestColumns = [
    { field: 'user', headerName: 'User', flex: 1 },
    { field: 'type', headerName: 'Request Type', flex: 1 },
    {
      field: 'actions',
      type: 'actions',
      headerName: 'View',
      width: 80,
      getActions: (params) => [
        <GridActionsCellItem
          icon={<VisibilityIcon sx={{ color: '#1976d2' }} />}
          label="View"
          onClick={() => handleRequestClick(params)}
          showInMenu={false}
          sx={{
            transition: 'transform 0.1s ease-in-out',
            '&:active': { transform: 'scale(0.95)' },
          }}
        />,
      ],
    },
  ];

  // Columns for Users
  const userColumns = [
    { field: 'name', headerName: 'Name', flex: 1 },
    { field: 'email', headerName: 'Email', flex: 1 },
    { field: 'role', headerName: 'Role', width: 120 },
    {
      field: 'active',
      headerName: 'Status',
      width: 120,
      headerAlign: 'center',
      align: 'center',
      renderCell: (params) =>
        params.value ? (
          <Typography color="success.main" >
            Active
          </Typography>
        ) : (
          <Typography color="error.main">
            Inactive
          </Typography>
        ),
    },
    {
      field: 'actions',
      type: 'actions',
      headerName: 'Manage',
      width: 110,
      getActions: (params) => [
        <GridActionsCellItem
          label="Activate/Deactivate"
          onClick={() => handleUserClick(params)}
          showInMenu={false}
          icon={
            params.row.active ? (
              <Typography color="error" sx={{ cursor: 'pointer' }}>
                Deactivate
              </Typography>
            ) : (
              <Typography color="primary" sx={{ cursor: 'pointer' }}>
                Activate
              </Typography>
            )
          }
          sx={{
            transition: 'transform 0.1s ease-in-out',
            '&:active': { transform: 'scale(0.95)' },
          }}
        />,
      ],
    },
  ];

  return (
    <Box sx={{ p: 3 }}>
      {/* Pending Requests Table */}
      <Typography
        variant="h5"
        sx={{ mb: 1, fontWeight: 'bold', color: '#1976d2' }}
      >
        Pending Requests
      </Typography>
      <Box sx={{ mb: 4 }}>
        <DataGrid
          rows={pendingRequests}
          columns={requestColumns}
          pageSize={5}
          rowsPerPageOptions={[5]}
          disableSelectionOnClick
          autoHeight
          slotProps={{
            header: {
              sx: {
                backgroundColor: '#1565c0',
                color: '#fff',
                fontWeight: 700,
              },
            },
          }}
        />
      </Box>

      {/* Active Users Table */}
      <Typography
        variant="h5"
        sx={{ mb: 1, fontWeight: 'bold', color: '#1976d2' }}
      >
        Active Users
      </Typography>
      <Box>
        <DataGrid
          rows={activeUsers}
          columns={userColumns}
          pageSize={5}
          rowsPerPageOptions={[5]}
          disableSelectionOnClick
          autoHeight
          slotProps={{
            header: {
              sx: {
                backgroundColor: '#1565c0',
                color: '#4ca041ff',
                fontWeight: 700,
              },
            },
          }}
          sx={{
        "& .MuiDataGrid-columnHeaders": {
          backgroundColor: "#1565c0", // Change background color
          color: "darkblue",          // Change text color
          fontSize: 20,               // Change font size
        },
      }}
        />
      </Box>

      {/* Request Details Dialog */}
      <Dialog open={openRequestDialog} onClose={handleRequestClose}>
        <DialogTitle>Request Details</DialogTitle>
        <DialogContent dividers>
          <Typography><strong>User:</strong> {selectedRequest?.user}</Typography>
          <Typography><strong>Type:</strong> {selectedRequest?.type}</Typography>
          <Typography sx={{ mt: 1 }}><strong>Details:</strong> {selectedRequest?.details}</Typography>

          {rejecting && (
            <TextField
              label="Rejection Comment"
              fullWidth
              multiline
              rows={3}
              value={rejectComment}
              onChange={(e) => setRejectComment(e.target.value)}
              sx={{ mt: 2 }}
              required
            />
          )}
        </DialogContent>
        <DialogActions>
          <Button
            onClick={handleApprove}
            color="success"
            sx={{ transition: 'transform 0.1s ease-in-out', '&:active': { transform: 'scale(0.95)' } }}
          >
            Approve
          </Button>
          <Button
            onClick={handleReject}
            color="error"
            sx={{ transition: 'transform 0.1s ease-in-out', '&:active': { transform: 'scale(0.95)' } }}
          >
            {rejecting ? 'Submit Reject' : 'Reject'}
          </Button>
          <Button onClick={handleRequestClose}>Cancel</Button>
        </DialogActions>
      </Dialog>

      {/* User Manage Dialog */}
      <Dialog open={openUserDialog} onClose={handleUserClose}>
        <DialogTitle>User Management</DialogTitle>
        <DialogContent dividers>
          <Typography><strong>Name:</strong> {selectedUser?.name}</Typography>
          <Typography><strong>Email:</strong> {selectedUser?.email}</Typography>
          <Typography sx={{ my: 2 }}><strong>Role:</strong> {selectedUser?.role}</Typography>
          <Typography>Status: {selectedUser?.active ? 'Active' : 'Inactive'}</Typography>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={toggleUserActive}
            color={selectedUser?.active ? 'error' : 'primary'}
            sx={{ transition: 'transform 0.1s ease-in-out', '&:active': { transform: 'scale(0.95)' } }}
          >
            {selectedUser?.active ? 'Deactivate' : 'Activate'}
          </Button>
          <Button onClick={handleUserClose}>Cancel</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
