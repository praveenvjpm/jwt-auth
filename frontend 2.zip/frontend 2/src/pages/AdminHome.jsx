import React from 'react'

export const AdminHome = () => {
  return (
    <div>AdminHome</div>
  )
}
